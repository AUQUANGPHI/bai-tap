s=input("nhap chuoi").split()
s.sort()
print(s)
