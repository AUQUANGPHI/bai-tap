# viết hàm sum với kết quả trả về
def sum(a,b):
    return a+b
c=sum(4,5);
print("tong cua 4 va 5 la"+str(c))