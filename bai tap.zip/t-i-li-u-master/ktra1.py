import math
c=50
h=30
value=[]
items=[x for x in input("nhap gia tri d:").split(',')]
for d in items:
    value.append(str(int(round(math.sqrt(2*c*float(d)/h)))))
    print(','.join(value))
