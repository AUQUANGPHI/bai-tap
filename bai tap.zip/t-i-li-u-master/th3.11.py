#tính lãi suất gửi ngân hàng 
t=float(input("nhap lai suat t"))
n=int(input("nhap so von ban dau"))
k=int(input("nhap so thang k"))
def benefit(t,n,k):
    s=t*n*k
    input(s)

benefit(t,n,k)
