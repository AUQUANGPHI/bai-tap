import mymath as mt
print(mt.square(2))
print(mt.square(3))
