ds=input('nhap chuoi:').split()
print("vi tri cua chuoi abc la",ds.index('abc'))