#sửa lỗi của đoạn chương trình
n1=int(input("enter n1 value"))
n2=int(input("enter n2 value"))
if n1>n2:
    print("ni is big")
else:
    print("n2 is big")