#tính diện tích, chu vi hình tròn
import math 
r=int(input("nhap ban kinh r"))
n=r*2*3.14
s=3.14*r**2
print('',s)
print('',n)




