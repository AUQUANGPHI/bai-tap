ds=input('nhap chuoi:').split()
