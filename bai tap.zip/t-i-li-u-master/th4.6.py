ds=input('nhap chuoi:').split()
ds.remove('123')
for ch in ds:
    print(ch)